function exibirUsuario(){

    var usuarioLogado = localStorage.getItem("user");

    if (!usuarioLogado){
        window.location="index.html";
    } else {
        var usuarioJson = JSON.parse(usuarioLogado);
        document.getElementById("perfil").innerHTML = usuarioJson.nome + "<br></br>" 
        + usuarioJson.racf
        //"<br><h4>" + usuarioJson.email +
        //"<br> Código : " + usuarioJson.id  + "</h4>";
        document.getElementById("fotoUsuario").innerHTML = 
        "<img src=images/" + usuarioJson.foto + " height=100 width=100>"
    }

    exibirParceiros()

}

function exibirParceiros(){

    var cabecalho={
        method : "GET",
        headers : {
            "Content-Type" : "application/json"
        }
    }
    fetch("http://localhost:8080/top10", cabecalho)
    .then(res => res.json())
    .then(res => popula(res))
    .catch(err=>{
        alert("Erro!");
    })

}

function popula(lista){

    var stringLista = "<tr>" +
        "<th>" +
            "Parceiro" +
        "</th>" +
        "<th>" +
            "Volume Transacional" +
        "</th>" +
    "</tr>";
    for (i = 0; i < lista.length; i++){
        stringLista += "<tr>" +
            "<td>" +
                lista[i].nomeAgente +
            "</td>" +
            "<td>" +
                lista[i].volumeTransacional +
            "</td>" +
        "</tr>";
    }

    document.getElementById("parceirosVolume").innerHTML = stringLista;

}